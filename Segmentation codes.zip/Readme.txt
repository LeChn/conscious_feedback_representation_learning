Finetuning experiments on segmentation.
1. I used BraTS2018 dataset in our experiments. Download the challenge data and follow the instruction of nnunet project (https://github.com/MIC-DKFZ/nnUNet) to reformulate the data as the style used in nnunet (https://github.com/MIC-DKFZ/nnUNet#dataset-conversion).
2. Set the pre-trained model path in ./network_architecture/generic_UNet_MoCo.py. This file will load the pre-trained model.
3. Set the percentage of labeled training data. Go to ./training/network_training/network_trainer.py. And find the code '''tr_keys = tr_keys[:int(0.1*len(tr_keys))]'(at 151th row), change 0.1 to other percentage you want. 
4. Run ./run/run_training.py to train.