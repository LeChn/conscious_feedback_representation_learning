import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from nnunet.network_architecture.deeplab3pp.sync_batchnorm import SynchronizedBatchNorm2d
from torch.nn import init
from nnunet.network_architecture.deeplab3pp.backbone import build_backbone
from nnunet.network_architecture.deeplab3pp.ASPP import ASPP
from nnunet.utilities.nd_softmax import softmax_helper

class Config():
	def __init__(self):
		self.MODEL_OUTPUT_STRIDE = 8
		self.MODEL_SHORTCUT_DIM = 48
		self.MODEL_SHORTCUT_KERNEL = 1
		self.TRAIN_BN_MOM = 0.0003
		self.MODEL_ASPP_OUTDIM = 128
		self.MODEL_BACKBONE = 'res50_atrous'
		self.MODEL_NUM_CLASSES = 4

class deeplabv3plus(nn.Module):
	def __init__(self, cfg):
		super(deeplabv3plus, self).__init__()
		self.backbone = None
		self.backbone_layers = None
		self.final_nonlin = softmax_helper
		input_channel = 2048
		self.aspp = ASPP(dim_in=input_channel,
				dim_out=cfg.MODEL_ASPP_OUTDIM,
				rate=cfg.MODEL_OUTPUT_STRIDE,
				bn_mom=0.0003)
		self.dropout1 = nn.Dropout(0.5)
		self.upsample4 = nn.UpsamplingBilinear2d(scale_factor=4)
		self.upsample_sub = nn.UpsamplingBilinear2d(scale_factor=cfg.MODEL_OUTPUT_STRIDE//4)

		indim = 256
		self.shortcut_conv = nn.Sequential(
				nn.Conv2d(indim, cfg.MODEL_SHORTCUT_DIM, cfg.MODEL_SHORTCUT_KERNEL, 1, padding=cfg.MODEL_SHORTCUT_KERNEL//2,bias=True),
				SynchronizedBatchNorm2d(cfg.MODEL_SHORTCUT_DIM, momentum=cfg.TRAIN_BN_MOM),
				nn.ReLU(inplace=True),
		)
		self.cat_conv = nn.Sequential(
				nn.Conv2d(cfg.MODEL_ASPP_OUTDIM+cfg.MODEL_SHORTCUT_DIM, cfg.MODEL_ASPP_OUTDIM, 3, 1, padding=1,bias=True),
				SynchronizedBatchNorm2d(cfg.MODEL_ASPP_OUTDIM, momentum=cfg.TRAIN_BN_MOM),
				nn.ReLU(inplace=True),
				nn.Dropout(0.5),
				nn.Conv2d(cfg.MODEL_ASPP_OUTDIM, cfg.MODEL_ASPP_OUTDIM, 3, 1, padding=1,bias=True),
				SynchronizedBatchNorm2d(cfg.MODEL_ASPP_OUTDIM, momentum=cfg.TRAIN_BN_MOM),
				nn.ReLU(inplace=True),
				nn.Dropout(0.1),
		)
		self.cls_conv = nn.Conv2d(cfg.MODEL_ASPP_OUTDIM, cfg.MODEL_NUM_CLASSES, 1, 1, padding=0)
		for m in self.modules():
			if isinstance(m, nn.Conv2d):
				nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
			elif isinstance(m, SynchronizedBatchNorm2d):
				nn.init.constant_(m.weight, 1)
				nn.init.constant_(m.bias, 0)
		self.backbone = build_backbone(cfg.MODEL_BACKBONE, os=cfg.MODEL_OUTPUT_STRIDE)
		self.backbone_layers = self.backbone.get_layers()

	def forward(self, x):
		x_bottom = self.backbone(x)
		#print(x_bottom.size())
		layers = self.backbone.get_layers()
		feature_aspp = self.aspp(layers[-1])
		feature_aspp = self.dropout1(feature_aspp)
		feature_aspp = self.upsample_sub(feature_aspp)

		feature_shallow = self.shortcut_conv(layers[0])
		feature_cat = torch.cat([feature_aspp,feature_shallow],1)
		result = self.cat_conv(feature_cat)
		result = self.cls_conv(result)
		result = self.upsample4(result)
		#result = self.final_nonlin(result)
		return result


if __name__ == '__main__':
	cfg = Config()
	a = torch.randn(1, 1, 1024, 512)
	net = deeplabv3plus(cfg)
	out = net(a)
	print(out.size())